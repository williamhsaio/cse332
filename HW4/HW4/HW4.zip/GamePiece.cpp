//GamePiece.cpp
// Halley Cummings
// Contains definition for GamePiece struct.

#include "stdafx.h"
#include "GamePieceHeader.h"
#include <iostream>
using namespace std;

GamePiece::GamePiece() //default constructor
	:displayChar(" "), color(noColor), name("") {}

